export async function analyzeImage() {
  return "Chart terdeteksi: tren naik (BUY signal)";
}